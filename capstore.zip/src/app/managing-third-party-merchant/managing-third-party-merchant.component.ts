import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managing-third-party-merchant',
  templateUrl: './managing-third-party-merchant.component.html',
  styleUrls: ['./managing-third-party-merchant.component.css']
})
export class ManagingThirdPartyMerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
