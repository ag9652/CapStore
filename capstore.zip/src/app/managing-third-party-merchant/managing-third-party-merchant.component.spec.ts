import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagingThirdPartyMerchantComponent } from './managing-third-party-merchant.component';

describe('ManagingThirdPartyMerchantComponent', () => {
  let component: ManagingThirdPartyMerchantComponent;
  let fixture: ComponentFixture<ManagingThirdPartyMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagingThirdPartyMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagingThirdPartyMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
